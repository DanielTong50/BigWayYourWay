import{l as o,a as r}from"../chunks/Bz4lMRFI.js";export{o as load_css,r as start};
