import{l as o,a as r}from"../chunks/DSr7hFQS.js";export{o as load_css,r as start};
